// HostedScan LLM Bridge — Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    hs_bridge_endpoint: "https://undesired-relatable-backtalk.ngrok-free.dev/api/ai/bridge-logs",
  });
});
