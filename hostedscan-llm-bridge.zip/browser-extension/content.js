// HostedScan LLM Bridge — Content Script
// Hooks fetch & XMLHttpRequest on ChatGPT domains to capture conversations.

const API_ENDPOINT_KEY = "hs_bridge_endpoint";
const DEFAULT_ENDPOINT = "https://undesired-relatable-backtalk.ngrok-free.dev/api/ai/bridge-logs";

let endpointUrl = DEFAULT_ENDPOINT;
let sessionId = crypto.randomUUID();
let conversationId = null;

// Load saved endpoint
try {
  chrome.storage.sync.get([API_ENDPOINT_KEY], (result) => {
    if (result[API_ENDPOINT_KEY]) endpointUrl = result[API_ENDPOINT_KEY];
  });
} catch (e) {}

// Listen for config updates from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "config_updated") {
    endpointUrl = msg.endpoint;
  }
  if (msg.type === "new_session") {
    sessionId = crypto.randomUUID();
    conversationId = null;
  }
  sendResponse({ ok: true });
});

// ---- Capture fetch() ----
const origFetch = window.fetch;
window.fetch = async function (...args) {
  const url = typeof args[0] === "string" ? args[0] : args[0]?.url;
  if (!url || !isChatGptApi(url)) return origFetch.apply(this, args);

  const body = args[1]?.body;
  let requestPayload = null;
  if (body && typeof body === "string") {
    try { requestPayload = JSON.parse(body); } catch (e) { requestPayload = body; }
  } else if (body) {
    try { requestPayload = body; } catch (e) {}
  }

  // Extract conversation ID from URL
  const match = url.match(/\/conversation\/([a-f0-9-]+)/);
  if (match) conversationId = match[1];

  const startTime = performance.now();
  const response = await origFetch.apply(this, args);
  const duration = Math.round(performance.now() - startTime);

  const cloned = response.clone();
  const contentType = cloned.headers.get("content-type") || "";
  let responseText = "";

  if (contentType.includes("text/event-stream")) {
    // SSE stream — collect all chunks
    const reader = cloned.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      fullText += decoder.decode(value, { stream: true });
    }
    responseText = fullText;
  } else {
    responseText = await cloned.text();
  }

  sendLog({
    method: args[1]?.method || "POST",
    url,
    requestPayload,
    responseText,
    status: response.status,
    duration,
    contentType,
  });

  return response;
};

// ---- Capture XMLHttpRequest ----
const origOpen = XMLHttpRequest.prototype.open;
const origSend = XMLHttpRequest.prototype.send;
const xhrMap = new WeakMap();

XMLHttpRequest.prototype.open = function (method, url) {
  xhrMap.set(this, { method, url: typeof url === "string" ? url : url?.toString() || "" });
  return origOpen.apply(this, arguments);
};

XMLHttpRequest.prototype.send = function (body) {
  const meta = xhrMap.get(this);
  if (meta && meta.url && isChatGptApi(meta.url)) {
    let requestPayload = null;
    if (body && typeof body === "string") {
      try { requestPayload = JSON.parse(body); } catch (e) { requestPayload = body; }
    }

    const match = meta.url.match(/\/conversation\/([a-f0-9-]+)/);
    if (match) conversationId = match[1];

    const startTime = performance.now();
    this.addEventListener("loadend", () => {
      const duration = Math.round(performance.now() - startTime);
      sendLog({
        method: meta.method,
        url: meta.url,
        requestPayload,
        responseText: this.responseText || "",
        status: this.status,
        duration,
        contentType: this.getResponseHeader("content-type") || "",
      });
    });
  }
  return origSend.apply(this, arguments);
};

function isChatGptApi(url) {
  const u = url.toLowerCase();
  return (
    u.includes("chatgpt.com/backend-api") ||
    u.includes("chat.openai.com/backend-api") ||
    u.includes("chatgpt.com/api/") ||
    u.includes("chat.openai.com/api/")
  );
}

async function sendLog(data) {
  if (!endpointUrl) return;
  try {
    await fetch(endpointUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId,
        conversationId,
        source: "bridge",
        method: data.method,
        url: data.url,
        request: data.requestPayload ? JSON.stringify(data.requestPayload) : "",
        response: data.responseText,
        status: data.status,
        durationMs: data.duration,
        contentType: data.contentType,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
      }),
    });
  } catch (e) {
    console.warn("[HostedScan Bridge] Failed to send log:", e);
  }
}
